===================
Django Flex EAV
===================


.. image:: https://img.shields.io/pypi/v/flex_eav.svg
        :target: https://pypi.python.org/pypi/flex_eav

.. image:: https://img.shields.io/travis/ali-avani/flex_eav.svg
        :target: https://travis-ci.com/ali-avani/flex_eav

.. image:: https://readthedocs.org/projects/django-flex-eav/badge/?version=latest
        :target: https://django-flex-eav.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status




Django project implementing the EAV pattern for the database models


* Free software: MIT license
* Documentation: https://django-flex-eav.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
